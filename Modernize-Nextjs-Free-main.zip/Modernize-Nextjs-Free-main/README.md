# <a href="https://modernize-nextjs-free.vercel.app/?ref=5">Modernize-nextjs-free</a>
Modernize Free Next.js 14 Admin Template with Material Ui + Typescript 
<!-- Place this tag where you want the button to render. -->
<a class="github-button" href="https://github.com/adminmart/Modernize-Nextjs-Free" data-color-scheme="no-preference: light; light: light; dark: dark;" data-icon="octicon-star" data-size="large" aria-label="Star adminmart/Modernize-Nextjs-Free on GitHub">Give a Star</a>
<!-- Main image of Template -->

  <img src="https://adminmart.com/wp-content/uploads/2023/03/modernize-free-next-js-admin-template.png" />



# Installation 👨🏻‍💻

> We recommend you use npm

1. Install all packages

```
npm i
```

2. Run Development Server

```
npm run dev
```

3. Build your project

```
npm run build
```



